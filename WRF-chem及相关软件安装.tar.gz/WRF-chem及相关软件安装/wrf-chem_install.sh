#!/bin/bash
#wget https://code.aliyun.com/101048689/wrfv3/raw/master/install.sh && chmod 777 install.sh && ./install.sh
echo "输入WRF-chem相关软件存储根目录"
read Filepath


#sudo date
#if [ ! -s "/usr/bin/gfortran" ] ;then
#apt-get update
#apt-get -y --force-yes install -y tcsh cpp m4 quota gfortran libjpeg8 unzip g++ 
#libhdf5-serial-dev h5utils
#fi

#本地环境变量修改
if [ ! -s "/opt/bashrc.bac" ] ;then
cp $Filepath/.bashrc /opt/bashrc.bac
cp $Filepath/.bashrc /tmp/bashrc.bac
echo "#add by 101048689

# for hdf5
export CPPFLAGS=-I/usr/local/HDF5/include
export LDFLAGS=-L/usr/local/HDF5/lib
export LD_LIBRARY_PATH=/usr/local/HDF5/lib

#for netcdf
export NETCDF=/usr/local/NETCDF
export LD_LIBRARY_PATH=/lib:$LD_LIBRARY_PATH

# set LAPACK
export LAPACK=/usr/local/lapack

#for ncarg
export NCARG_ROOT=/usr/local/ncarg
export MANPATH=/man:
export DISPLAY=:0.0

#for chem
export WRF_CHEM=1
export WRF_KPP=1
export YACC='/usr/local/yacc/yacc -d'
export FLEX=/usr/local/flex/bin/flex
export FLEX_LIB_DIR=/usr/local/flex/lib
export EM_CORE=1
export NMM_CORE=0
export PATH=$PATH:.:/usr/local/yacc:/usr/local/flex/bin
export WRFIO_NCD_LARGE_FILE_SUPPORT=1

#add by 101048689
"  >> $Filepath/.bashrc
source $Filepath/.bashrc
echo " /usr/local/libpng/lib" >>/etc/ld.so.conf
ldconfig
else
cp /opt/bashrc.bac $Filepath/.bashrc
echo "#add by 101048689

# for hdf5
export CPPFLAGS=-I/usr/local/HDF5/include
export LDFLAGS=-L/usr/local/HDF5/lib
export LD_LIBRARY_PATH=/usr/local/HDF5/lib

#for netcdf
export NETCDF=/usr/local/NETCDF
export LD_LIBRARY_PATH=/lib:$LD_LIBRARY_PATH

# set LAPACK
export LAPACK=/usr/local/lapack

#for ncarg
export NCARG_ROOT=/usr/local/ncarg
export MANPATH=/man:
export DISPLAY=:0.0

#for chem
export WRF_CHEM=1
export WRF_KPP=1
export YACC='/usr/local/yacc/yacc -d'
export FLEX=/usr/local/flex/bin/flex
export FLEX_LIB_DIR=/usr/local/flex/lib
export EM_CORE=1
export NMM_CORE=0
export PATH=$PATH:.:/usr/local/yacc:/usr/local/flex/bin
export WRFIO_NCD_LARGE_FILE_SUPPORT=1

#add by 101048689
"  >> $Filepath/.bashrc
source $Filepath/.bashrc
echo " /usr/local/libpng/lib" >>/etc/ld.so.conf
fi

#加载环境变量
export CPPFLAGS=-I/usr/local/HDF5/include
export LDFLAGS=-L/usr/local/HDF5/lib
export LD_LIBRARY_PATH=/usr/local/HDF5/lib
export NETCDF=/usr/local/NETCDF
export PATH=.:/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games:/usr/local/games:/usr/local/yacc:/usr/local/flex/bin
export LD_LIBRARY_PATH=/lib:$LD_LIBRARY_PATHexport WRFIO_NCD_LARGE_FILE_SUPPORT=1
export CC=gcc
export FC=gfortran
export WRF_CHEM=1
export WRF_KPP=1
export YACC='/usr/local/yacc/yacc -d'
export FLEX=/usr/local/flex/bin/flex
export FLEX_LIB_DIR=/usr/local/flex/lib
export EM_CORE=1
export NMM_CORE=0

#zlib
if [ ! -s "/usr/local/lib/libz.a" ] ;then
cd /opt
rm -rf /opt/zlib-1.2.8
rm /opt/zlib-1.2.8.tar.gz*
wget https://code.aliyun.com/101048689/wrfv3/raw/master/bin/zlib-1.2.8.tar.gz
tar -xvf zlib-1.2.8.tar.gz
rm zlib-1.2.8.tar.gz
cd /opt/zlib-1.2.8
./configure
make
make install
fi

#jasper
if [ ! -s "/usr/local/lib/libjasper.a" ] ;then
cd /opt
rm -rf /opt/jasper-1.900.1
rm /opt/jasper-1.900.1.zip*
wget https://code.aliyun.com/101048689/wrfv3/raw/master/bin/jasper-1.900.1.zip
unzip jasper-1.900.1.zip
rm jasper-1.900.1.zip
cd /opt/jasper-1.900.1
./configure
make
make install
fi

#配置hdf5库
if [ ! -s "/usr/local/HDF5/lib/libhdf5.a" ] ;then
cd /opt
rm -rf /opt/hdf5-1.8.14
rm /opt/hdf5-1.8.14.zip*
wget https://code.aliyun.com/101048689/wrfv3/raw/master/bin/hdf5-1.8.14.zip
unzip hdf5-1.8.14.zip
rm hdf5-1.8.14.zip
cd /opt/hdf5-1.8.14
source $Filepath/.bashrc
FC=gfortran CC=gcc ./configure --prefix=/usr/local/HDF5 --with-zlib=/usr/local --enable-fortran
make
make check
make install
source $Filepath/.bashrc
fi

#netcdf
if [ ! -s "/usr/local/NETCDF/lib/libnetcdf.a" ] ;then
cd /opt
rm -rf /opt/netcdf
rm /opt/netcdf-4.1.2.tar.gz*
wget ftp://ftp.unidata.ucar.edu/pub/netcdf/old/netcdf-4.1.2.tar.gz
tar -zxvf netcdf-4.1.2.tar.gz
rm netcdf-4.1.2.tar.gz
cd /opt/netcdf-4.1.2
./configure --disable-dap --disable-netcdf-4 --prefix=/usr/local/NETCDF
make
make check
make install
source $Filepath/.bashrc
fi


#flex
cd /usr/local
if [ ! -s "/usr/local/flex/lib/libfl.a" ] ;then
rm -rf flex
rm flex.tar.gz*
wget http://www.ncl.ucar.edu/Download/files/flex.tar.gz
tar -xzf flex.tar.gz
rm flex.tar.gz*
mv /usr/local/flex-2.5.3 /usr/local/flex
cd ./flex
./configure --prefix=/usr/local/flex
make
make install
source $Filepath/.bashrc
fi

#yacc
cd /usr/local
if [ ! -s "/usr/local/yacc/yacc" ] ;then
rm byacc.1.9.tar*
wget ftp://ftp.cs.berkeley.edu/pub/4bsd/byacc.1.9.tar.Z
gzip -d byacc.1.9.tar.Z
rm byacc.1.9.tar.Z
mkdir /usr/local/yacc
tar -xf byacc.1.9.tar -C /usr/local/yacc
cd /usr/local/yacc
make
cd /usr/local
rm byacc.1.9.tar*
source $Filepath/.bashrc
fi

#wrf_chem
cd $Filepath
if [ ! -s "WRF-4.0.2/README" ] ;then
rm -rf $Filepath/WRF-4.0.2
rm $Filepath/v4.0.2.tar.gz*
wget https://github.com/wrf-model/WRF/archive/v4.0.2.tar.gz
tar -xvf v4.0.2.tar.gz
chmod 777 $Filepath/WRF-4.0.2/chem/KPP/compile_wkc
fi

if [ ! -s "WRF-4.0.2/main/wrf.exe" ] || [ ! -s "WRF-4.0.2/chem/convert_emiss.exe" ] ;then
cd $Filepath/WRF-4.0.2
./clean -a
source $Filepath/.bashrc
clear
echo "这个需要手动选择 serial  GNU (gfortran/gcc) ，各人机器可能都不一样，我的是32。"
echo "第二个选项选basic 1 "
echo "enter键开始选择，如果没有出现选择框应该是安装出错了，建议手动查找原因。"
read Test
./configure
echo "正在编译wrf"
./compile em_real >&checkwrf.log
clear
ls -ln main/*.exe
echo "四个exe文件且未出现无效链接则编译成功。否则请中断安装并手动查找原因。"
echo "enter键继续"
read Test
./compile emi_conv >& emcompile.log
echo "正在编译convert_emiss"
ls -ln chem/*.exe
echo "生成convert_emiss.exe则编译成功"
echo "enter继续"
read Test
fi

#jpegsrc
if [ ! -s "/usr/local/lib/libjpeg.a" ] ;then
cd /opt
rm -rf /opt/jpeg-9a
rm /opt/jpegsrc.v9a.tar.gz*
wget https://code.aliyun.com/101048689/wrfv3/raw/master/bin/jpegsrc.v9a.tar.gz
tar -xvf jpegsrc.v9a.tar.gz
rm jpegsrc.v9a.tar.gz
cd /opt/jpeg-9a
./configure
make
make install
fi

#libpng
if [ ! -s "/usr/local/lib/libpng16.a" ] ;then
cd /opt
rm -rf /opt/libpng-1.6.16/
rm /opt/libpng-1.6.16.tar.gz*
wget https://code.aliyun.com/101048689/wrfv3/raw/master/bin/libpng-1.6.16.tar.gz
tar -xvf libpng-1.6.16.tar.gz
rm libpng-1.6.16.tar.gz
cd /opt/libpng-1.6.16/
source $Filepath/.bashrc
./configure
make
make install
fi

#安装NCL
#sudo apt-get install ncl
if [ ! -s "/usr/local/ncarg/lib/libncarg.a" ] ;then
cd /opt
rm ncarg.tar.gza*
rm -rf /opt/ncarg
rm -rf /usr/local/ncarg
wget https://code.aliyun.com/101048689/wrfv3/raw/master/bin/ncarg.tar.gzaa
wget https://code.aliyun.com/101048689/wrfv3/raw/master/bin/ncarg.tar.gzab
wget https://code.aliyun.com/101048689/wrfv3/raw/master/bin/ncarg.tar.gzac
cat ncarg.tar.gza* | tar -xz
rm ncarg.tar.gza*
mv /opt/ncarg /usr/local/
# ng4ex gsun01n -clean
fi

#GRIB2
if [ ! -s "/usr/local/grib2/tar_all" ] ;then
cd /usr/local
rm wgrib2.tgz*
rm -rf /usr/local/grib2
wget https://code.aliyun.com/101048689/wrfv3/raw/master/bin/wgrib2.tgz
tar -xvf  wgrib2.tgz
rm wgrib2.tgz
cd /usr/local/grib2
make
fi

#wps
cd $Filepath
if [ ! -s "WPS/README" ] ;then
rm v4.1.tar.gz*
rm -rf $Filepath/WPS
wget https://github.com/wrf-model/WPS/archive/v4.1.tar.gz
tar -zxvf v4.1.tar.gz
rm v4.1.tar.gz
mv $Filepath/WPS-4.1 $Filepath/WPS
cd $Filepath/WPS
./clean -a
echo "这个需要手动选择 Linux x86_64, gfortran (serial) ，各人机器可能都不一样，我的是1。"
echo "enter键开始选择，如果没有出现选择框应该是安装出错了，建议手动查找原因。"
read Test
./configure
echo "正在编译wps"
./compile wps >&checkwps.log
./compile util >&checkutil.log
ln -sf ungrib/Variable_Tables/Vtable.GFS ./Vtable
clear
ls -ln *.exe
ls -ln util/*.exe
echo "出现的所有exe文件，并未出现无效链接则编译成功。"
echo "enter键继续"
read Test
fi

#lapack
if [ ! -s "/usr/local/lapack-3.5.0/README" ] ;then
cd /usr/local
rm lapack-3.5.0.tgz*
rm -rf /usr/local/lapack-3.5.0
wget https://code.aliyun.com/101048689/wrfv3/raw/master/bin/lapack-3.5.0.tgz
tar -xvf lapack-3.5.0.tgz
rm lapack-3.5.0.tgz
cd /usr/local/lapack-3.5.0
make
fi

#ARWpost
cd $Filepath
if [ ! -s "ARWpost/src/ARWpost.exe" ] ;then
rm ARWpost_V3.tar.gz*
rm -rf $Filepath/ARWpost
wget https://code.aliyun.com/101048689/wrfv3/raw/master/bin/ARWpost_V3.tar.gz
tar -xvf ARWpost_V3.tar.gz
rm ARWpost_V3.tar.gz
cd $Filepath/ARWpost
clear
echo "这个需要手动选择 x86_64 gfortran compiler，各人机器可能都不一样，我的是3"
echo "enter键开始选择"
read Test
./configure
echo "正在编译ARWpost"
./compile >&checkarwpost.log
clear
ls -ln *.exe
echo "出现的exe文件并未出现无效链接则编译成功。"
echo "enter键继续"
read Test
fi


















